function ret = HestonPIntegrand2(phi,kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K,Type)
if Type==2
ret = real(exp(-i*phi*log(K)).*Hestf2(phi,kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)./(i*phi));
else
ret = real(exp(-i*phi*log(K)).*Hestf2(phi-i,kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)./(i*phi)/Hestf2(-i,kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0));
end