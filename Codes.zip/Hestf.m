function f = Hestf(phi,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)
x = log(s0);
kafang=sqrt((alphaQ)^2+2*eta^2*phi.*i);
phip=kafang-alphaQ;
phin=kafang+alphaQ;
J=-1/VGnuQ*log(1+VGthetaQ*VGsigmaQ.*phi*i+0.5*VGsigmaQ^2*VGnuQ*phi.^2)+...
    1/VGnuQ*phi.*i*log(1+VGthetaQ*VGsigmaQ-0.5*VGsigmaQ^2*VGnuQ);
D=2*phi.*i.*(1-exp(-kafang*T))./(phip.*exp(-kafang*T)+phin);
E=((r-0.5*sigma_s^2+rho*sigma_s*eta)*phi.*i-0.5*sigma_s^2*phi.^2)*T-alphaQ*betaQ/(eta^2)*(phip*T+2*log((phip.*exp(-kafang.*T)+phin)./(2*kafang)))+J*T;
f = exp(E + D*delta0 + i*phi*x);

