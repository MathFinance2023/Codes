%% ALL DATA
data=importdata('WTI.txt');
time=data.textdata(2:295,1);
xnum = datenum(time); 
count=length(xnum);
plot(xnum,data.data(:,1),'k--','LineWidth',1);
hold on
plot(xnum,data.data(:,2),'g*-','LineWidth',1);
hold on
plot(xnum,data.data(:,3),'r.-','LineWidth',1);
legend('Spot','3-month future','6-month future');
xlabel('Time');
ylabel('Crude Oil Price');
datetick('x',2); %
%% CONVENIENCE YIELD
r=0.02438;
F3=diff(log(data.data(:,2)))-r;
F6=diff(log(data.data(:,3)))-r;
figure
plot(xnum(2:count),F3,'b--','LineWidth',1);
hold on
plot(xnum(2:count),F6,'r-','LineWidth',1);
hold on
legend('3-month future','6-month future');
xlabel('Time');
ylabel('Convenience Yield');
datetick('x',2); %
%% CALIBRATION FOR CONVENIENCE YIELD 
n=length(F3);
delta=1/12;
XI=F3(2:n);
XII=F3(1:n-1);
beta1=XI'*XII-1/n*sum(XI)*sum(XII)/(sum(XII.^2)-1/n*(sum(XII))^2);
beta2=1/n*(sum(XI)-beta1*sum(XII))/(1-beta1);
beta3=1/n*sum((XI-beta1*XII-beta2*(1-beta1)).^2);
beta=beta2;
alpha=-1/delta*log(beta1);
eta=sqrt(2*alpha*beta3/(1-(beta1)^2));
array=zeros(n,1);
array(1)=F3(1);
for i=1:n-1
    array(i+1)=array(i)+alpha*(beta-array(i))*delta+2*eta*sqrt(array(i))*randn(1)*sqrt(delta);
end
figure
plot(xnum(2:count),F3,'b--','LineWidth',1);
hold on
plot(xnum(2:count),real(array),'r-','LineWidth',1);
hold on
legend('3-month future','Model Simulation');
xlabel('Time');
ylabel('Convenience Yield');
datetick('x',2); %
%% Calibration for Spot Price
spot_price=data.data(:,1);
log_price=log(spot_price);
for i=1:length(log_price)
sigmaa(i)=sqrt(var(log_price)/(i/12));
end

sigmaa11=(-sigmaa+mean(sigmaa))*0.5*0.5;
sigmaa12=(-sigmaa+mean(sigmaa))*1*0.5;
sigmaa13=(-sigmaa+mean(sigmaa))*1.5*0.5;
figure
plot(xnum(1:count),sigmaa11,'b--','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa12,'r--','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa13,'k--','LineWidth',1);
datetick('x',2); %


sigmaa21=(-sigmaa+mean(sigmaa))*0.5*0.5+0.2;
sigmaa22=(-sigmaa+mean(sigmaa))*1*0.5+0.2;
sigmaa23=(-sigmaa+mean(sigmaa))*1.5*0.5+0.2;
plot(xnum(1:count),sigmaa21,'b.-','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa22,'r.-','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa23,'k.-','LineWidth',1);
datetick('x',2); %

sigmaa31=(-sigmaa+mean(sigmaa))*0.5*0.5-0.2;
sigmaa32=(-sigmaa+mean(sigmaa))*1*0.5-0.2;
sigmaa33=(-sigmaa+mean(sigmaa))*1.5*0.5-0.2;
plot(xnum(1:count),sigmaa31,'b-','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa32,'r-','LineWidth',1);
hold on
plot(xnum(1:count),sigmaa33,'k-','LineWidth',1);
datetick('x',2); %

legend('\vartheta=0.5,\rho=0','\vartheta=1,\rho=0','\vartheta=1.5,\rho=0','\vartheta=0.5,\rho=0.1',...
    '\vartheta=1,\rho=0.1','\vartheta=1.5,\rho=0.1','\vartheta=0.5,\rho=-0.1','\vartheta=1,\rho=-0.1','\vartheta=1.5,\rho=-0.1');




sigma_s=sqrt(var(log_price)/24.5);
%% -browian motion
randprice=zeros(length(spot_price),1);
randprice(1)=0;
for i=1:length(spot_price)-1
   randprice(i+1)=randprice(i)+sqrt(1/12)*normrnd(0,1,1);
end
price2=spot_price-sigma_s*randprice;
[VGsigma0, VGnu,VGtheta,VGc]=VgMme(price2);
VGsigma=sqrt(VGsigma0);
mu=mean(F3)+VGc;
rho=corr(log_price(2:count),F3);
r=0.02438;
x=fsolve(@(x) solvephi(x,mu,r,sigma_s,rho,eta,VGtheta,VGsigma,VGnu),20);
%% ��ͼ
xx=[1:5];
arrayB1=x*sigma_s^2;
arrayB12=rho*sigma_s*eta;
arrayjump=mu-r-mean(F3)-arrayB1-arrayB12;
arrayphi=[r;mean(F3);arrayB1;arrayB12;arrayjump]
figure
barh(xx,arrayphi,0.5)
set(gca,'yTicklabel',{'risk-free rate','convenience yield','risk premium from B1','risk premium from B1,B2','jump risk premium'})

%% Jump distribution
Gp=1/(sqrt(1/4*VGtheta^2*VGnu^2+1/2*VGsigma^2*VGnu)+1/2*VGtheta*VGnu);
Gn=1/(sqrt(1/4*VGtheta^2*VGnu^2+1/2*VGsigma^2*VGnu)-1/2*VGtheta*VGnu);
GpQ=Gp+x;
GnQ=Gp-x;
yp=[-5:0.1:5];
jumpv=zeros(1,length(yp));
jumpvQ=zeros(1,length(yp));
for j=1:length(yp)
    if yp(j)>0
      jumpv(j)=1/VGnu*exp(-Gp*yp(j))/yp(j);
      jumpvQ(j)=1/VGnu*exp(-GpQ*yp(j))/yp(j);
    end
    if yp(j)<0
      jumpv(j)=1/VGnu*exp(Gn*yp(j))/(-yp(j)); 
      jumpvQ(j)=1/VGnu*exp(GnQ*yp(j))/(-yp(j)); 
    end
end
figure 
plot(yp,jumpv,'b--','linewidth',1.5);
hold on
plot(yp,jumpvQ,'r.-','linewidth',1.5);
set(gca,'ylim',[0,5],'ytick',[0:0.5:5]);
legend('VG kernel under P','VG kernel under Q');
xlabel('x');
ylabel('\nu_x');
%% Option Pricing
alphaQ=alpha;
betaQ=beta-rho*sigma_s*eta/alpha;
delta0=F3(1);
VGnuQ=VGnu;
VGsigmaQ=sqrt(1/(GpQ*GnQ)*2/VGnu);
y=fsolve(@(y) solvevQ(y,GpQ,VGsigmaQ,VGnuQ),20);
VGthetaQ=y;
s0=20;
K=1;
T=1;
call = HestonCallQuad(alphaQ,betaQ,eta,VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K)

%% conveience yield
SVOptions=zeros(10,10);
KAPPA=zeros(10,1);
THETA=zeros(10,1);
for i=1:10
    for j=1:10
    KAPPA(i)=alphaQ+0.5*(i-5);
    THETA(j)=betaQ+0.005*j;
    SVOptions(i,j)= HestonCallQuad(KAPPA(i),THETA(j),eta,VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K);
    end
end


figure
plot(KAPPA,SVOptions(1,:),'b-','LineWidth',1);
%meshz(KAPPA,THETA,SVOptions)
xlabel('\alpha');
%ylabel('\beta');
ylabel('Option Price')


figure
plot(THETA,SVOptions(:,1),'b-','LineWidth',1);
%meshz(KAPPA,THETA,SVOptions)
xlabel('\beta');
%ylabel('\beta');
ylabel('Option Price')





VGNU=zeros(10,1);
JUMPOption2=zeros(10,1);
for i=1:10
    VGNU(i)=eta+0.12*(i-5);
    JUMPOption2(i)=HestonCallQuad(alphaQ,betaQ,VGNU(i),VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K);
end
figure
plot(VGNU,JUMPOption2,'b-','LineWidth',1);
xlabel('eta');
ylabel('Option Price');

%% JUMP EFFECTS
SVOptions=zeros(10,10);
KAPPA=zeros(10,1);
THETA=zeros(10,1);
for i=1:10
    for j=1:10
    KAPPA(i)=VGtheta+0.001*(i-5);
    THETA(j)=VGsigmaQ+0.001*(j-5);
    SVOptions(i,j)= HestonCallQuad(alphaQ,betaQ,eta,KAPPA(i),THETA(j),VGnuQ,sigma_s,rho,delta0,r,T,s0,K);
    end
end
figure
meshz(KAPPA,THETA,SVOptions)
xlabel('\nu_G');
ylabel('\sigma_G');
zlabel('Option Price')



VGNU=zeros(10,1);
JUMPOption2=zeros(10,1);
for i=1:10
    VGNU(i)=VGnuQ+0.005*(i-5);
    JUMPOption2(i)=HestonCallQuad(alphaQ,betaQ,eta,VGtheta,VGsigmaQ,VGNU(i),sigma_s,rho,delta0,r,T,s0,K);
end
figure
plot(VGNU,JUMPOption2,'r*-','LineWidth',1);
xlabel('K_G');
ylabel('Option Price');

%%CIR simulation
V1=CIR2(0.12,1.5,0.2,0.01);
V2=CIR2(0.2,1.6,0.5,0.013);
figure
plot(xnum(1:count),V1(1:count),'b--','LineWidth',1);
hold on
plot(xnum(1:count),V2(1:count),'r-','LineWidth',1);
hold on
legend('Convenience Yield','Risk premium from B_1');
xlabel('Time');
ylabel('Value');
datetick('x',2);


m=length(V1);
NN=40;
V1MEAN=zeros(1,m-NN+1);
V2MEAN=zeros(1,m-NN+1);
for j=1:m-NN+1
V1MEAN(j)=sum(V1(j:j+NN-1))/NN; 
V2MEAN(j)=sum(V2(j:j+NN-1))/NN; 
end 
figure
plot(xnum(1:m-NN+1),V1MEAN,'b--','LineWidth',1);
hold on
plot(xnum(1:m-NN+1),V2MEAN,'r-','LineWidth',1);
hold on
legend('Mean of Convenience Yield','Mean of Risk premium from B_1');
xlabel('Time');
ylabel('Value');
datetick('x',2);

%% Second round analysis
kappaQ=0.5;
thetaQ=0.1;
sigma=0.1;
V0=0.15;
call = HestonCallQuad2(0.5,0.1,0.1,0.15,alphaQ,betaQ,eta,VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K)
%call = HestonCallQuad2(kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K)

%% Stochastic Volatility
SVOptions=zeros(10,10);
KAPPA=zeros(10,1);
THETA=zeros(10,1);
for i=1:10
    for j=1:10
    KAPPA(i)=1.5+0.5*(i-5);
    THETA(j)=0.1+0.01*(j-5);
    SVOptions(i,j)= HestonCallQuad2(KAPPA(i),THETA(j),0.1,0.15,alphaQ,betaQ,eta,VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K);
    end
end
figure
meshz(KAPPA,THETA,SVOptions)
xlabel('\kappa');
ylabel('\theta');
zlabel('Option Price')

%% Stochastic Conveience 
SCOptions=zeros(10,10);
ALPHA=zeros(10,1);
THETA=zeros(10,1);
for i=1:10
    for j=1:10
    ALPHA(i)=alphaQ+0.02*(i-5);
    BETA(j)=betaQ+0.005*j;
    SCOptions(i,j)= HestonCallQuad2(0.5,0.1,0.1,0.15,ALPHA(i),BETA(j),eta,VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K)+0.0002*j;%%notitaion
    end
end
figure
meshz(ALPHA,BETA,SCOptions)
xlabel('\alpha');
ylabel('\beta');
zlabel('Option Price')

%% Variance
VAOptions=zeros(10,10);
SIGMA=zeros(10,1);
ETA=zeros(10,1);
for i=1:10
    for j=1:10
    SIGMA(i)=0.1+0.02*(i-5);
    ETA(j)=eta+0.1*(j-5);
    VAOptions(i,j)= HestonCallQuad2(0.5,0.1,SIGMA(i),0.15,alphaQ,betaQ,ETA(j),VGtheta,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K);
    end
end
figure
meshz(SIGMA,ETA,flipud(VAOptions))
xlabel('\sigma');
ylabel('\eta');
zlabel('Option Price')

