function F=solvephi(x,mu,r,sigma,rho,eta,vg,sigmag,kg)
F=[r-mu-0.0194+x*sigma^2+rho*eta*sigma-1/kg*log(1+vg*sigmag-0.5*sigmag^2*kg)
    +1/kg*log(1+(1-x)*vg*sigmag-0.5*(1-x)^2*sigmag^2*kg)-1/kg*log(1-x*vg*sigmag-0.5*x^2*sigmag^2*kg)];
%
% mu=0.1799;r=0.02438;sigma=3.17;rho=0.0499;eta=1.01;vg=0.2150;sigmag=0.7253;kg=-0.1306;
%F = solvephi(x,c)
%         F = [ 2*x(1) - x(2) - exp(c*x(1))
%               -x(1) + 2*x(2) - exp(c*x(2))];