function f = Hestf2(phi,kappaQ,thetaQ,sigma,V0,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)
x = log(s0);
zeta=sqrt((kappaQ-rho*sigma*phi.*i).^2+sigma^2*(phi.*i+phi.^2));
xip=zeta-(kappaQ-rho*sigma*phi.*i);
xin=zeta+(kappaQ-rho*sigma*phi.*i);
kafang=sqrt((alphaQ)^2+2*eta^2*phi.*i);
phip=kafang-alphaQ;
phin=kafang+alphaQ;
J=-1/VGnuQ*log(1+VGthetaQ*VGsigmaQ.*phi*i+0.5*VGsigmaQ^2*VGnuQ*phi.^2)+...
    1/VGnuQ*phi.*i*log(1+VGthetaQ*VGsigmaQ-0.5*VGsigmaQ^2*VGnuQ);
D=2*phi.*i.*(1-exp(-kafang*T))./(phip.*exp(-kafang*T)+phin);
C=(-phi.^2-phi.*i).*(1-exp(-zeta*T))./(xip.*exp(-zeta*T)+xin);
E=r*phi.*i*T-kappaQ*thetaQ/(sigma^2)*(xip*T+2*log((xip.*exp(-zeta.*T)+xin)./(2*zeta)))-...
    alphaQ*betaQ/(eta^2)*(phip*T+2*log((phip.*exp(-kafang.*T)+phin)./(2*kafang)))+J*T;
f = exp(E + C*V0+D*delta0 + i*phi*x);

