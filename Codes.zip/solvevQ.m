function F=solvevQ(y,GpQ,VGsigmaQ,VGnuQ)
F=[1/(sqrt(1/4*y^2*VGnuQ^2+1/2*VGsigmaQ^2*VGnuQ)+1/2*y*VGnuQ)-GpQ];
%