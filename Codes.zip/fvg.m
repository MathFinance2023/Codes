function f = fvg( x )
f = x*(3+2*x)^2/((1+4*x+2*x^2)*(1+x));
end