function [sigma, nu,theta,c] = VgMme(ts)
% Copyright (C) 2013-2018 matpij.com
% Example [sigma, nu,theta,c] = VgMme(SPX)

X = diff(log(ts));
T = 24.5;
h = T/length(X);

m1 = mean(X);
m2 = var(X);
skw = skewness(X);
excessKrt = kurtosis(X)-3;
xi=fzero(@(x) fvg(x)-3*skw^2/excessKrt,0);

sigma = sqrt(m2/(h*(1+xi)));
nu = h/3*excessKrt*((1+xi)^2/(1+4*xi+2*xi^2));
theta = skw*(var(X))^(3/2)/(h*sigma^2*nu*(3+2*xi));
c = m1/h-theta;

end