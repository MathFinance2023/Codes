function call = HestonCallQuad(alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K)
call = s0*exp(-r*T)*HestonP(alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K,1) - ...
K*exp(-r*T)*HestonP(alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K,2);

% example  call=HestonCallQuad(0.01,0.1,0.1,0.2,0.1,0.2,1,0.1,0.15,0.03,0.1,1.4,1.5)

