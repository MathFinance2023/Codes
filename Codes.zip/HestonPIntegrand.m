function ret = HestonPIntegrand(phi,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0,K,Type)
if Type==2
ret = real(exp(-i*phi*log(K)).*Hestf(phi,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)./(i*phi));
else
ret = real(exp(-i*phi*log(K)).*Hestf(phi-i,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0)./(i*phi)/Hestf(-i,alphaQ,betaQ,eta,VGthetaQ,VGsigmaQ,VGnuQ,sigma_s,rho,delta0,r,T,s0));
end